import { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Breadcrumbs } from '../components/ui/Breadcrumbs';
import { getCategoryBySlug, getProductsByCategory } from '../data/mockData';
import { ProductGrid } from '../components/product/ProductGrid';

export function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const category = getCategoryBySlug(slug || '');
  const products = getProductsByCategory(slug || '');

  useEffect(() => {
    if (category) {
      document.title = `${category.name} | Abundant Merchandise`;
    }
  }, [category]);

  if (!category) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Category not found</h1>
        <Link to="/shop" className="text-brand hover:underline">
          Browse all products
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <Breadcrumbs
        items={[
          { label: 'Shop', path: '/shop' },
          { label: category.name },
        ]}
      />

      <div className="relative h-48 md:h-64 rounded-xl overflow-hidden mb-8">
        <img
          src={category.image}
          alt={category.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-3xl md:text-4xl font-heading font-bold mb-2">
              {category.name}
            </h1>
            <p className="text-white/80">{category.description}</p>
          </div>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-ink-500 mb-4">No products in this category yet.</p>
          <Link to="/shop" className="text-brand hover:underline">
            Browse all products
          </Link>
        </div>
      ) : (
        <ProductGrid
          products={products}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6"
        />
      )}
    </div>
  );
}
